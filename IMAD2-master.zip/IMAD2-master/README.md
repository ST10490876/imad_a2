# Project Title

This Flashcard Questionnaire app is a effective tool designed to help users.Users can create and organise flashcards with questions and answers on any topic.
Installation
Install my-project with npm

  npm install my-project
  cd my-project
  Features
Light/dark mode toggle
Live previews
Fullscreen mode
Cross platform
